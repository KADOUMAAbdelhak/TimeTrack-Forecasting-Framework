# Anonymized artifact bundle (reviewer-facing)

This archive intentionally excludes Git history, remotes, author names, emails,
institution names, and absolute local paths.

Frozen prediction NPZ files and large raw datasets are not redistributed here.
Reviewers may request access through the editor, or use the anonymized
read-only repository mirror linked from the manuscript Code and Artifact
Availability statement once the mirror ID is inserted by the authors.

## Neutral snapshot IDs

- Prediction snapshot P2
- Statistical snapshot S1
- Peak snapshot K1
- Robustness snapshot R2a / R2b
- Reporting snapshot F2

Exact repository freeze-tag names are withheld for double-anonymized review.
